// 1. Set chart margins and dimensions

const margin = {
    top: 50,
    right: 80,
    bottom: 50,
    left: 160
};

const width = 900 - margin.left - margin.right;
const height = 500 - margin.top - margin.bottom;


// 2. Create the SVG chart

const svg = d3.select("#chart")
    .append("svg")
    .attr("width", width + margin.left + margin.right)
    .attr("height", height + margin.top + margin.bottom);


// 3. Create the chart group

const g = svg.append("g")
    .attr("transform", `translate(${margin.left},${margin.top})`);


// 4. Create the scales

const x = d3.scaleLinear()
    .range([0, width]);

const y = d3.scaleBand()
    .range([0, height])
    .padding(0.2);


// 5. Create the axes

const xAxis = g.append("g")
    .attr("transform", `translate(0,${height})`);

const yAxis = g.append("g");


// 6. Create continent colours

const color = d3.scaleOrdinal()
    .domain(["Asia", "Europe", "Africa", "Americas", "Oceania"])
    .range(["tomato", "steelblue", "green", "orange", "purple"]);


// 7. Load the Gapminder CSV file

d3.csv("dataset/gapminder.csv", d3.autoType)

    .then(function(data) {

        console.log("CSV loaded successfully!");
        console.log("Total rows:", data.length);


        // 8. Keep data for 1952 and 2007

        const filteredData = data.filter(d =>
            d.year === 1952 || d.year === 2007
        );


        // 9. Create a function to draw the chart

        function updateChart(year) {

            // Select the chosen year

            const yearData = filteredData.filter(d =>
                d.year === year
            );


            // Sort from highest income to lowest

            yearData.sort((a, b) =>
                d3.descending(a.gdpPercap, b.gdpPercap)
            );


            // Keep only the top 10 countries

            const top10 = yearData.slice(0, 10);


            // Set the scales

            x.domain([
                0,
                d3.max(top10, d => d.gdpPercap) * 1.1
            ]);

            y.domain(top10.map(d => d.country));


            // Update the axes

            xAxis
                .transition()
                .duration(750)
                .call(d3.axisBottom(x));

            yAxis
                .transition()
                .duration(750)
                .call(d3.axisLeft(y));


            // Connect the data to the bars

            const bars = g.selectAll("rect")
                .data(top10, d => d.country);


            // Remove unnecessary bars

            bars.exit()
                .transition()
                .duration(750)
                .attr("width", 0)
                .remove();


            // Create new bars

            const newBars = bars.enter()
                .append("rect")
                .attr("x", 0)
                .attr("y", d => y(d.country))
                .attr("width", 0)
                .attr("height", y.bandwidth())
                .attr("fill", d => color(d.continent))
                .style("cursor", "pointer");


            // Add hover information

            newBars.append("title");


            // Update existing and new bars

            newBars.merge(bars)
                .transition()
                .duration(750)
                .attr("y", d => y(d.country))
                .attr("height", y.bandwidth())
                .attr("width", d => x(d.gdpPercap))
                .attr("fill", d => color(d.continent));


            // Display country and income on hover

            g.selectAll("rect")
                .select("title")
                .text(d =>
                    `${d.country}: ${d3.format(",.0f")(d.gdpPercap)}`
                );


            // Update the heading

            d3.select("#chart-title")
                .text(`Top 10 Richest Countries (${year})`);

        }


        // 10. Add a chart title

        svg.append("text")
            .attr("id", "chart-title")
            .attr("x", margin.left)
            .attr("y", 25)
            .attr("font-size", "16px")
            .attr("font-weight", "bold")
            .text("Top 10 Richest Countries (2007)");


        // 11. Make the buttons work

        d3.select("#year1952")
            .on("click", function() {
                updateChart(1952);
            });

        d3.select("#year2007")
            .on("click", function() {
                updateChart(2007);
            });


        // 12. Display 2007 first

        updateChart(2007);

    })

    .catch(function(error) {

        console.error("Could not load Gapminder CSV:", error);

    });